package main

//go:generate make mac
//go:generate make windows
//go:generate make linux

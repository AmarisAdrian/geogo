package main

import (
	"testing"

	"github.com/xxjwxc/gormt/data/cmd"
)

func TestDomain(t *testing.T) {
	cmd.Execute()
}

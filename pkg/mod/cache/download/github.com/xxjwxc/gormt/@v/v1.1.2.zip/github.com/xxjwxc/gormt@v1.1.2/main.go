package main

import "github.com/xxjwxc/gormt/data/cmd"

func main() {
	cmd.Execute()
}

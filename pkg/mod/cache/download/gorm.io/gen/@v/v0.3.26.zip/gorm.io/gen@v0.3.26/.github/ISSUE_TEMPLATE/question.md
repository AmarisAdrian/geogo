---
name: 💬  Question
about: The resources of the GORM team are limited, please search documents/google/issues/test cases before ask 🙏
labels: type:question
assignees: riverchu

---

<!-- DON'T CHANGE THE TEMPLATE -->

## Your Question

<!-- Most likely your question already answered https://github.com/go-gorm/gorm/issues or described in the document https://gorm.io, ✨ Search Before Asking ✨ -->

<!-- Ask your question in English, minimalist example is highly recommended, please `Report a bug` for bugs -->

## The document you expected this should be explained

<!-- The document link you expected this question should be explained in our [official documents site](https://gorm.io) -->

## Expected answer

<!-- What you want -->

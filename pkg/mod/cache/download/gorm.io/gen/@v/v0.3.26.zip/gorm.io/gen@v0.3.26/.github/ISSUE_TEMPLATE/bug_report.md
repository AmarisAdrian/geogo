---
name: 🐛  Report a bug
about: Your issue may already be reported! please search on the https://github.com/go-gorm/gorm/issues before creating one 🥳
labels: type:bug
assignees: riverchu 

---

## GORM Playground Link

<!--
To ensure your issue be handled, the issue *MUST* include a GORM Playground Pull Request Link that can reproduce the bug, which is important to help others understand your issue effectively and make sure the issue hasn't been fixed, refer: https://github.com/go-gorm/playground

Without the link, your issue most likely will be IGNORED

CHANGE FOLLOWING URL TO YOUR PLAYGROUND LINK
-->

https://github.com/go-gorm/playground/pull/1

## Description

<!-- Your use case -->

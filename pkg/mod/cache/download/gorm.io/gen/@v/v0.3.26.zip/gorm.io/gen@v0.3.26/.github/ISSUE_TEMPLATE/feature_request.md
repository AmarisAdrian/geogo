---
name: 🍻  Feature request
about: Suggest an idea, Pull Request welcome 🚀
labels: type:feature
assignees: riverchu

---

<!-- DON'T CHANGE THE TEMPLATE -->

## Describe the feature

<!-- Describe the requested Feature -->

## Motivation

<!-- Describe the motivation behind it -->

## Related Issues

<!-- Link related issues here -->
